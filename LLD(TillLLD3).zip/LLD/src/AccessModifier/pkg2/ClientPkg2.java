package AccessModifier.pkg2;

import AccessModifier.pkg1.Student;

public class ClientPkg2 {
    public static void main(String args[]) {
        Student s = new Student();
        s.name = "Ravi";
    }
}
