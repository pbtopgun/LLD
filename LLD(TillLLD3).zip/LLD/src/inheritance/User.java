package inheritance;

public class User {
    String userName;
    String password;
    String displayId;
    String displayPicURL;

    void login(){
        System.out.println("User logging in");
    }
}
