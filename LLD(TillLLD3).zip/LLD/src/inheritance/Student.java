package inheritance;

public class Student extends User{
 double psp;   

 void pauseCourse(){
     System.out.println("Pausing course");
 }

}
