package encapsulation;

public class Student{    
    int age;   /// [TYPE] [NAME]
    String name;
    String batch;
    double psp;

    void changeBatch(String bString){   ///[RETURN TYPE] [NAME OF THE METHOD](<Parameters>)
        this.batch = bString;
    }

    void pauseCourse() {
        ////
    }
}
