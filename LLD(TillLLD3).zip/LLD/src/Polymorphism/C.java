package Polymorphism;

public class C extends B{
    void hello() {
        System.out.println("hello from C");
    }
}
